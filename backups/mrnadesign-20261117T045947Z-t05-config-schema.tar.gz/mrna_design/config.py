"""The validated pipeline configuration (T05, `SPEC-notebook-shell.md` NS-2.1).

`RunConfig` is the single input to the pipeline. It carries the approved
three-class field taxonomy (NS-1.2a, G19/G20 resolved 2026-11-16):

- ``required`` — a sequence the user must supply: ``protein_sequence`` when the
  design module runs, ``sequence_input`` when it does not.
- ``material`` — a choice that changes what a user would order. Only
  ``backbone_path`` is material, and it has **no default**: absent means the
  plasmid branch is skipped, never a guessed vector (DC-3.0).
- ``representation`` — conventions with declared defaults: construct source,
  template type, poly(A) length, seeds, report wording, output naming.

Every field is tagged in its JSON schema with ``field_class`` so the manifest
can enumerate what affected the output without a second hand-written list
(NS-2.3, "no hidden defaults"). Validation failures are raised as
:class:`ConfigValidationError` carrying field-level, human-readable messages —
never a bare pydantic traceback in the user's path (NS-2.2).

The taxonomy and each field's rule are recorded in ``docs/config-fields.md``;
changing one there or here is a specification change, not a cleanup.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)
from pydantic_core import ErrorDetails

FIELD_CLASS_KEY = "field_class"
"""JSON-schema key that carries a field's taxonomy class."""

DEFAULT_SEED = 42
"""One global default seed, overridable per adapter (RD-3.6)."""

DEFAULT_REPORT_TITLE = "mRNADesign run report"

PLASMID_POLY_A_DEFAULT = 100
"""Default encoded poly(A) length for plasmid templates (DC-2.2, applied at T06)."""


class FieldClass(StrEnum):
    """The approved NS-1.2a classification of a configuration field."""

    REQUIRED = "required"
    MATERIAL = "material"
    REPRESENTATION = "representation"


@dataclass(frozen=True)
class FieldSpec:
    """One enumerable configuration field, for manifest recording (NS-2.3)."""

    name: str
    field_class: FieldClass
    has_default: bool
    default: object


def _classified(field_class: FieldClass, **kwargs: Any) -> Any:
    """Declare a field with its taxonomy class in the JSON schema."""
    extra = dict(kwargs.pop("json_schema_extra", None) or {})
    extra[FIELD_CLASS_KEY] = field_class.value
    return Field(**kwargs, json_schema_extra=extra)


class ConfigValidationError(ValueError):
    """Configuration is invalid; ``messages`` are field-level and renderable.

    Callers (the notebook, the headless runner) catch this and display
    ``messages``. Nothing here is a traceback: that is the NS-2.2 contract.
    """

    def __init__(self, messages: list[str]) -> None:
        self.messages = tuple(messages)
        super().__init__("\n".join(self.messages))

    def __str__(self) -> str:
        return "\n".join(self.messages)


def _format_validation_error(error: ErrorDetails) -> str:
    """Render one pydantic error as ``field.path: reason`` without machinery."""
    location = ".".join(str(part) for part in error["loc"])
    message = error["msg"]
    prefix = "Value error, "
    if message.startswith(prefix):
        message = message[len(prefix) :]
    return f"{location}: {message}" if location else message


def format_validation_errors(error: ValidationError) -> list[str]:
    """Field-level messages for a pydantic validation failure (NS-2.2)."""
    return [_format_validation_error(detail) for detail in error.errors()]


class RunConfig(BaseModel):
    """The single validated pipeline input (NS-2.1).

    Unknown keys are rejected rather than silently dropped: a misspelled field
    must not vanish from the manifest.
    """

    model_config = ConfigDict(extra="forbid")

    # -- required: the sequence class (conditionally required, NS-1.2/NS-1.7) --
    protein_sequence: str | None = _classified(
        FieldClass.REQUIRED,
        default=None,
        description=(
            "Protein to design from. Required when run_modules includes 'design' "
            "(NS-1.2, RD-1.1); normalisation is owned by rna-design (RD-1.4)."
        ),
    )
    sequence_input: str | None = _classified(
        FieldClass.REQUIRED,
        default=None,
        description=(
            "mRNA or DNA sequence for a Module-2-only run. Required when "
            "run_modules excludes 'design' (NS-1.7, DC-1.1)."
        ),
    )

    # -- material: never defaulted (NS-1.2a, DC-3.0) --------------------------
    backbone_path: str | None = _classified(
        FieldClass.MATERIAL,
        default=None,
        description=(
            "User-supplied GenBank or FASTA backbone. No default: absent resolves "
            "the plasmid branch to skipped with a recovery hint (DC-3.0/DC-3.1)."
        ),
    )

    # -- representation: declared conventions (defaults are written out) -----
    run_modules: list[Literal["design", "construct"]] = _classified(
        FieldClass.REPRESENTATION,
        default_factory=lambda: ["design", "construct"],
        min_length=1,
        description="Modules to execute; each may appear once (NS-1.7).",
    )
    template_type: Literal["pcr", "plasmid"] = _classified(
        FieldClass.REPRESENTATION,
        default="pcr",
        description=(
            "Construct template type (DC-2.0). 'plasmid' is reachable only when a "
            "backbone is supplied."
        ),
    )
    poly_a_length: int | None = _classified(
        FieldClass.REPRESENTATION,
        default=None,
        gt=0,
        description=(
            "Encoded poly(A) length for plasmid templates; defaulted to 100 nt at "
            "resolution. 'pcr' carries no tract and must leave this unset (DC-2.2)."
        ),
    )
    construct_source: str | None = _classified(
        FieldClass.REPRESENTATION,
        default="codonbert",
        min_length=1,
        description=(
            "Named adapter whose result is built into the construct (RD-4.1b delta, "
            "G25-B). Not 'the first result' and never a ranking."
        ),
    )
    default_adapters: list[str] | None = _classified(
        FieldClass.REPRESENTATION,
        default=None,
        description=(
            "Per-step default adapter set, encoded at T40. Null means 'not encoded "
            "yet', never 'run nothing' (NS-1.2, RD-4.1a)."
        ),
    )
    seed: int = _classified(
        FieldClass.REPRESENTATION,
        default=DEFAULT_SEED,
        description="Global seed, overridable per adapter via adapter_seeds (RD-3.6).",
    )
    adapter_seeds: dict[str, int] = _classified(
        FieldClass.REPRESENTATION,
        default_factory=dict,
        description="Per-adapter seed overrides; every resolved seed is recorded (RD-3.6).",
    )
    report_title: str = _classified(
        FieldClass.REPRESENTATION,
        default=DEFAULT_REPORT_TITLE,
        min_length=1,
        description="Report wording; the research-use caveat itself is mandated elsewhere.",
    )
    run_label: str | None = _classified(
        FieldClass.REPRESENTATION,
        default=None,
        pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$",
        description=(
            "Optional filename-safe label used when naming the output directory; "
            "absent uses the ledger-generated run id (T09, NS-4.1)."
        ),
    )

    @field_validator("run_modules")
    @classmethod
    def _modules_are_unique(
        cls, modules: list[Literal["design", "construct"]]
    ) -> list[Literal["design", "construct"]]:
        if len(set(modules)) != len(modules):
            raise ValueError("must not repeat a module; list each module at most once")
        return modules

    @field_validator("protein_sequence", "sequence_input")
    @classmethod
    def _sequence_is_not_blank(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("must not be empty; omit the field if it is not supplied")
        return value

    @field_validator("backbone_path")
    @classmethod
    def _backbone_is_not_blank(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError(
                "must not be empty; omit the field to resolve the plasmid branch to skipped"
            )
        return value

    @field_validator("adapter_seeds")
    @classmethod
    def _adapter_seed_ids_are_not_blank(cls, seeds: dict[str, int]) -> dict[str, int]:
        if any(not adapter_id.strip() for adapter_id in seeds):
            raise ValueError("adapter ids must not be empty")
        return seeds

    @model_validator(mode="after")
    def _required_input_and_branch_rules(self) -> RunConfig:
        needs_design = "design" in self.run_modules
        if needs_design and self.protein_sequence is None:
            raise ValueError(
                "protein_sequence: required when run_modules includes 'design' "
                "(NS-1.2); use a Module-2-only run with sequence_input instead"
            )
        if not needs_design and self.sequence_input is None:
            raise ValueError(
                "sequence_input: required when run_modules does not include 'design' "
                "(NS-1.7, DC-1.1)"
            )

        if self.template_type == "plasmid" and self.backbone_path is None:
            raise ValueError(
                "backbone_path: required for template_type='plasmid'; no backbone is "
                "bundled or invented (DC-3.0) — supply one or use template_type='pcr'"
            )
        if self.template_type == "pcr" and self.backbone_path is not None:
            raise ValueError(
                "template_type: a backbone_path was supplied but template_type is 'pcr'; "
                "set template_type='plasmid' to use it, or remove backbone_path — a "
                "supplied backbone is never ignored silently"
            )
        if self.template_type == "pcr" and self.poly_a_length is not None:
            raise ValueError(
                "poly_a_length: not used for template_type='pcr'; the tail is added "
                "enzymatically and the control does not exist (DC-2.2)"
            )
        return self

    @classmethod
    def field_specs(cls) -> tuple[FieldSpec, ...]:
        """Enumerate every field with its class and declared default (NS-2.3).

        Fails closed: a field without a taxonomy class is a programming error,
        not a field to record as "unknown".
        """
        specs: list[FieldSpec] = []
        for name, info in cls.model_fields.items():
            extra = info.json_schema_extra
            raw = extra.get(FIELD_CLASS_KEY) if isinstance(extra, dict) else None
            if not isinstance(raw, str):
                raise RuntimeError(f"config field {name!r} has no {FIELD_CLASS_KEY} classification")
            try:
                field_class = FieldClass(raw)
            except ValueError as exc:  # pragma: no cover - only reachable by a bad edit
                raise RuntimeError(f"config field {name!r} has unknown class {raw!r}") from exc
            has_default = not info.is_required()
            specs.append(
                FieldSpec(
                    name=name,
                    field_class=field_class,
                    has_default=has_default,
                    default=info.get_default(call_default_factory=True) if has_default else None,
                )
            )
        return tuple(specs)


def parse_config(data: Mapping[str, Any]) -> RunConfig:
    """Validate raw configuration, raising field-level messages (NS-2.2).

    Raises:
        ConfigValidationError: when any field is invalid; ``messages`` names each
            field and the rule it broke, with no pydantic internals.
    """
    try:
        return RunConfig.model_validate(data)
    except ValidationError as error:
        raise ConfigValidationError(format_validation_errors(error)) from error
