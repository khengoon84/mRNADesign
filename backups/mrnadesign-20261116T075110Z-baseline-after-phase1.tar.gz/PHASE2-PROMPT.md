# Phase 2 prompt — paste into a new session

You are continuing the **mRNADesign** project at `/home/khengoon/projects/mRNADesign` — a public open-source Google Colab notebook that orchestrates proven open-source tools for mRNA sequence design and DNA construct design. Phase 1 (specification) is complete and approved. Your job is **Phase 2 only: produce an implementation plan and a task breakdown.** Do not write product code.

## Read first, in this order

1. `mRNADesign.md` — statement of intent + scope decisions (source of truth for scope, users, constraints, out-of-scope)
2. `CAPABILITY-MAP.md` — module ids, dependency direction, build order, V1/V2 line
3. `SPEC-notebook-shell.md`
4. `SPEC-rna-design.md`
5. `SPEC-rna-qc-additions.md`
6. `SPEC-dna-construct.md`
7. `SPEC-experimental-tier.md` — V2 and deferred; read it only to confirm it stays out of V1

Then load the `planning-and-task-breakdown` skill and follow spec-driven-development Phase 2.

## Scope

- **In:** V1 only — `notebook-shell` → `rna-design` → `rna-qc-additions` → `dna-construct`.
- **Out:** `experimental-tier`, `cloning-simulation`, and everything on the specs' Deferred lists.

## Produce

- `tasks/plan.md` — component dependency graph, implementation order, what can be parallel vs must be sequential, risks with mitigations, verification checkpoints between phases.
- `tasks/todo.md` — tasks sized to one focused session, ≤5 files each, each with **Acceptance / Verify / Files**, ordered by dependency rather than perceived importance.

Prefer vertical slices: get `notebook-shell` + one adapter producing a real run bundle early, then widen. The golden case is the SARS-CoV-2 spike RBD fixture referenced by the specs; each spec's Commands section already defines its verification commands.

## Hard constraints — do not relax

- **No new algorithms.** Adapters and wrappers only. No codon optimiser, UTR model, signal-peptide/TM predictor, or recoding loop written here. RD-SC7's grep test stays.
- **Colab-only runtime.** No local install for users, no web app, no terminal step.
- **Pinned dependencies** at exact revisions, with licence and provenance recorded in `mrna_design/tools/manifest.yaml`.
- **One notebook.** The default path must complete with only the protein sequence entered.
- `not_run` is a distinct status from `pass`; skipped branches carry a recovery hint; no auto-ranking of candidates.
- **Never invent a default for a material choice** (backbone, construct source, vendor profile).

## Planning constraints

- `notebook-shell` comes first: it owns the config schema, contracts scaffolding, bootstrap, run ledger, and test harness. Nothing else can be verified without it.
- Define `DesignRequest` / `DesignResult` / `MrnaRecord` before implementing any adapter.
- QC's post-assembly pass (QC-1.6) is a runtime edge, not a build-order change — `dna-construct` never depends on QC.
- Turn the specs' Open Questions into **explicit tasks with gates**, not silent assumptions. At minimum: LinearDesign redistribution terms; licence verification for every pinned engine; Optimus 5-Prime CPU budget (decides whether the engine or the reference library is the default 5′UTR source); reference UTR curation and permission; vendor/generic profile sourcing; transmembrane predictor choice. If a gate is unresolved, mark the task blocked — do not pick a default on the user's behalf.
- The repo is not yet git-initialised. Make initialisation, licence choice, and first commit an early task, but **ask** before choosing a licence.

## Stop conditions

- Do not create source files, notebook cells, adapters, or tests.
- If two specs contradict each other, stop and report both requirement IDs; do not choose a winner.
- Finish by summarising the plan, listing what can start immediately, and listing decisions you need from me.
- Then wait for review — do not begin implementation.
