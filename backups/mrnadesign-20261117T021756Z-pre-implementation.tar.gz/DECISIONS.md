# Decision log — mRNADesign

Append-only. Newest last. Never edit or delete an entry; if a decision is overturned, add a new entry that supersedes it and says which one it replaces.

Format per entry: date, id, decision, why, what it rules out. Dates are ISO. IDs are `D-<n>` and are never reused.

---

## D-001 — 2026-11-16 — No new algorithms

Decision: the project is an orchestrator. Every capability comes from an existing open-source tool behind an adapter or plugin; no codon optimiser, UTR model, structure predictor, signal-peptide predictor, or recoding loop is written in this repo.

Why: the claim "an orchestrator over proven tools" is the whole reason a non-programmer can trust the output. Writing one small optimiser would make that claim unverifiable.

Rules out: QC performing recoding (it measures only), in-house "lightweight" predictors, and any fix that starts with "it would be easy to just compute...".

## D-002 — 2026-11-16 — Colab-only, single notebook, two modules

Decision: one public Colab notebook; Module 1 (`rna-design`) and Module 2 (`dna-construct`) are independently runnable in the same flow. No local install, no CLI prerequisite, no standalone web app.

Why: the target user is a molecular biologist without a terminal. Every additional surface is another thing that can fail without a recovery path.

Rules out: a packaged Python library as the primary deliverable, a hosted web service, and a "run locally if Colab is slow" escape hatch.

## D-003 — 2026-11-16 — LinearDesign is CDS-only

Decision: LinearDesign performs no UTR optimisation. The adapter is declared as a CDS engine, and UTRs come from elsewhere.

Why: confirmed from upstream. A spec that assumed joint 5′UTR+CDS design would have silently produced mRNA records with absent UTRs while claiming a complete design.

Rules out: presenting LinearDesign output as a whole-mRNA optimum; cross-adapter "best mRNA" rankings.

## D-004 — 2026-11-16 — UTRs: reference library + Optimus 5-Prime

Decision: V1 ships a cited reference-UTR library as data (`data/utrs/`), each entry carrying sequence, region, source, licence, and the label *reference, not optimised*. Optimus 5-Prime supplies 5′UTRs when it fits the CPU budget; the library is the fallback. Users may override either region.

Why: no V1 engine designs a 3′UTR, so without the library "Run all" cannot produce a complete mRNA. Inventing placeholder UTRs was the alternative and it is worse than a labelled reference.

Rules out: placeholder sequences, and treating a reference 3′UTR as a designed one in any report.

## D-005 — 2026-11-16 — Engines are plugins; selection is per step

Decision: engines live behind a versioned plugin contract and are selected per step (5′UTR, CDS, 3′UTR, each QC predictor). Mixing engines is normal.

Why: the user asked for the option to choose one tool or another throughout the workflow. Per-step is what makes that meaningful — a single global tool choice would make a mixed record impossible.

Rules out: fetch-and-execute plugin loading from a URL. Plugins come from pinned installs or local files only, because a public notebook that runs arbitrary remote code cannot make a reliability claim.

## D-006 — 2026-11-16 — Project licence MIT; research restriction sits on the dependency

Decision: the project's own code is MIT. LinearDesign's research-only / non-commercial restriction is recorded as an attribute of that dependency, not as a narrowing of the project licence.

Why: MIT cannot be restricted to research use without ceasing to be MIT. Putting the restriction where it actually applies keeps the licence honest and makes the constraint visible at the point of use.

Rules out: a project licence that claims to be MIT while forbidding commercial use, and silence about the restricted default engine.

Consequence: the default path is research-only because LinearDesign is on it. The notebook requires acknowledgement, and the README states that commercial use requires replacing or separately licensing that engine.

## D-007 — 2026-11-16 — DNAChisel is the only route to depletion

Decision: CpG/UpA depletion, forbidden-motif avoidance, and restriction-site removal are expressed as DNAChisel constraints at the design step. RNA QC measures and never recodes.

Why: it satisfies D-001 without a recoder, and it separates "what the design was asked to satisfy" from "what QC observed" — which is the distinction a reviewer will look for.

Rules out: a recoding loop in QC; silent relaxation of unsatisfiable constraints (they must be reported by name and location).

## D-008 — 2026-11-16 — Structure metrics are engine-attributed

Decision: ViennaRNA and LinearFold both report MFE/ensemble metrics, and every value names the engine that produced it. Two engines' values are never merged into one series or ranked against each other.

Why: the energy models differ. Comparing them would look like a design improvement when it is only a change of ruler.

## D-009 — 2026-11-16 — Signal peptide via DeepSig / PEFT-SP

Decision: signal-peptide prediction uses DeepSig or PEFT-SP. SignalP is excluded.

Why: a licence-gated predictor leaves most users with a permanent `not_run`, which reads as a broken check. Both replacements are open source and installable.

Open: transmembrane prediction has no chosen engine yet and stays `not_run` with its own reason.

## D-010 — 2026-11-16 — PARADE ships in V1, opt-in only

Decision: PARADE (MIT, `autosome-ru/parade`) is registered in V1 as the single experimental engine, offering 5′/3′UTR generation and UTR activity/stability prediction. It is never in `default_adapters`, never in a fallback chain, and never reachable without an explicit user action in that run. Maturity `best_effort` until its conda-only environment is repinned to pip.

Why: it is the only viable 3′UTR engine, and the user asked for it to be selectable when Optimus 5-Prime cannot fit the Colab free tier. Shipping it with the full reliability contract binding is cheaper than retrofitting the contract later.

Rules out: substituting PARADE automatically when proven UTR sources fail (RD-2.11); any experimental result affecting run status or QC status columns.

## D-011 — 2026-11-16 — No version control yet; dated snapshots instead

Decision: the workspace is not a git repository. History is kept as dated immutable snapshots (`scripts/snapshot.sh`, `snapshots/`) plus this append-only log.

Why: the user asked not to start git yet. Snapshots give a recoverable state without committing to a repository layout, a licence file, or a `.gitignore` that would be decided prematurely.

Rules out: treating the working directory as recoverable. A snapshot on the same disk does not survive the failure it protects against, so snapshots must be copied off-machine.

Note: `git init` publishes nothing (no account, no network) and remains the expected floor once implementation starts. This entry records a deliberate deferral, not a rejection of version control.

## D-012 — 2026-11-16 — Phase 1 approved; Phase 2 in a separate session

Decision: the specification set (`CAPABILITY-MAP.md` + six `SPEC-*.md`) is the Phase 1 deliverable and is approved. Planning and task breakdown happen in a new session with `PHASE2-PROMPT.md`.

Why: spec and plan are different modes of thinking, and the planning session needs the specs, not the history of drafting them.
