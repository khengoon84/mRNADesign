mRNADesign snapshot
===================

Name:        mrnadesign-20261117T030128Z-d020-in-workspace-backups
Taken (UTC): 20261117T030128Z
Label:       d020-in-workspace-backups
Files:       15
Source:      /home/khengoon/projects/mRNADesign

What this is
------------
A point-in-time copy of the mRNADesign working tree. The project has no git
repository yet by decision (DECISIONS.md D-011); this archive is the record.

Excluded on purpose
-------------------
backups/       (never nest snapshots)
outputs/       (generated run bundles)
agent-skills/  (agent tooling, not part of the deliverable)
caches and bytecode

Restore
-------
  mkdir restore && tar -xzf mrnadesign-20261117T030128Z-d020-in-workspace-backups.tar.gz -C restore

Verify integrity
----------------
  (cd backups && sha256sum -c SHA256SUMS)

Scope note
----------
A snapshot is a state, not an approval. It records what the files said at
20261117T030128Z, not that they were correct. Archives live on the same disk as the
workspace; an off-machine copy is not required by decision (D-020), and the
risk that follows from that is recorded there.
